REM HOTSOS_ILO
REM Copyright (C) 2006 Hotsos Enterprises Ltd
REM
REM This library is free software; you can redistribute it and/or
REM modify it under the terms of the GNU Lesser General Public
REM License as published by the Free Software Foundation; either
REM version 2.1 of the License, or (at your option) any later version.
REM
REM This library is distributed in the hope that it will be useful,
REM but WITHOUT ANY WARRANTY; without even the implied warranty of
REM MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
REM Lesser General Public License for more details.
REM
REM You should have received a copy of the GNU Lesser General Public
REM License along with this library; if not, write to the Free Software
REM Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
REM
set feedback off
spool hotsos_ilo_install.log
PROMPT ========================================================================
PROMPT
PROMPT This script will install the HOTSOS Oracle Instrumentation Library
PROMPT package and its associated utilities.
PROMPT
PROMPT Packages Installed:
PROMPT
PROMPT * HOTSOS_SYSUTIL 
PROMPT
PROMTP This package provides shielded access to the KSDDDT and DSDWRT 
PROMPT procedures contained in the DBMS_SYSTEM package. This procedure is 
PROMPT installed int the SYS schema and EXECUTE is granted PROMPT to PUBLIC
PROMPT
PROMPT * HOTSOS_ILO_TASK
PROMPT
PROMPT This package provides the libraries required to accurately instrument 
PROMPT the Oracle side of any code. The package is installed in the schema of 
PROMPT your choice (Default: HOTSOS) and EXECUTE is granted to PUBLIC
PROMPT
PROMPT * HOTSOS_ILO_TIMER
PROMPT
PROMPT In the very near future, this package will allow users to record the duration 
PROMPT a given task to run in a local table. This allows for analysis of run-time 
PROMPT trending and can be used to force actions based on SLA levels.
PROMPT
PROMPT NOTE: Currently the package body of HOTSOS_ILO_TIMER is null, but the package
PROMPT       needs to be present for HOTSOS_ILO_TASK to work correctly.
PROMPT
PROMPT ========================================================================
PROMPT 
PROMPT Preparing to start. Hit enter to continue...
PAUSE
accept syspw char prompt '*** Please enter the sys password: ' HIDE
PROMPT '... Connecting as SYS... '
Connect sys/&&syspw as sysdba;
PROMPT 
PROMPT ... Installing HOTSOS_SYSUTIL Package Spec
@HOTSOS_SYSUTIL.PKS
PROMPT ... Installing HOTSOS_SYSUTIL Package Body
@HOTSOS_SYSUTIL.PKB
PROMPT ... Granting EXECUTE privson HOTSOS_SYSUTIL to PUBLIC
grant execute on hotsos_sysutil to public;
PROMPT =========================================================================
PROMPT 
PROMPT Getting ready to connect to the user who will own the HOTSOS_ILO packages.
PROMPT 
PROMPT NOTE: THIS USER MUST EXIST PRIOR TO EXECUTING THIS SCRIPT.
PROMPT
ACCEPT h_user char default HOTSOS prompt '*** Please enter the user you wish to own HOTSOS_ILO: [hotsos]'
ACCEPT H_PW   char default HOTSOS prompt '*** Please enter the password for this user: [hotsos] ' HIDE
PROMPT *** Granting EXECUTE privs on SYS.DBMS_MONITOR to &&h_user   
GRANT EXECUTE ON  SYS.DBMS_MONITOR TO &&h_user;
PROMPT *** Connecting as &&h_user
connect &&h_user/&&h_pw 
PROMPT *** Installing HOTSOS_ILO_TASK Package Spec
@HOTSOS_ILO_TASK.pks
PROMPT *** Installing HOTSOS_ILO_TASK Package Body
@HOTSOS_ILO_TASK.pkb
PROMPT *** Installing HOTSOS_ILO_TIMER Package Spec
@HOTSOS_ILO_TIMER.pks
PROMPT *** Installing HOTSOS_ILO_TIMER Package Body
@HOTSOS_ILO_TIMER.pkb
PROMPT *** Granting EXECUTE privs on HOTSOS_ILO_* to PUBLIC
grant execute on HOTSOS_ILO_TASK to PUBLIC;
grant execute on HOTSOS_ILO_TIMER to PUBLIC;
spool off
