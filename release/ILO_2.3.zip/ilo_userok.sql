
spool ilo_install_user.sql
prompt start ilo_grant_user.sql
spool off
