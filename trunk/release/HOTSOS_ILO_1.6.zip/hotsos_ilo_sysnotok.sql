set termout on

prompt Sorry, but you must authenticate yourself with AS SYSDBA credentials
prompt
prompt I am now terminating SQL*Plus
prompt
exit
