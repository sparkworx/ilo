
spool hotsos_ilo_install_user.sql
prompt start hotsos_grant_user.sql
spool off
