set termout on

prompt Good, you are authenticated with AS SYSDBA credentials
prompt
